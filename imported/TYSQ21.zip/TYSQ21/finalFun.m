function y=finalFun(x)

global z;
global k;
global phi;

d1=x(1);
d2=x(2);

%if i==1
    y(1)=EF31(d1,d2,1);
    %end

%if i==2
    y(2)=EF31(d1,d2,2);
    %end