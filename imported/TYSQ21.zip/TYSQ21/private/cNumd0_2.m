function y=c_Numd0_2(d2)

global z;
global k;
global phi;

y=Ccd2_12*d2*k(1);