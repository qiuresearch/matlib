function data=bNumd01()

global z;
global k;
global phi;

data=-Ccd2_22*k(1)*x(1)+Ccd2_12*k(1)*x(2);