function data=aFNumd01()

global z;
global k;
global phi;

data=-Ccd2_22*k(1)*v(1)+Ccd2_12*k(1)*v(2);