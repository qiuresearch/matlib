function y=c_Dend1_2(d2)

global z;
global k;
global phi;

y=Ccd1_21(d2)*Ccd2_12(d2)*d2-Ccd1_11(d2)*Ccd2_22(d2)*d2;