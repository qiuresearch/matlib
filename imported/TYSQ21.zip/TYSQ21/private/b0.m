function data=b0()

global z;
global k;
global phi;

data = -3*phi/2/(1-2*phi+phi^2);