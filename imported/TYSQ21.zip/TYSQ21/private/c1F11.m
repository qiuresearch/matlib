function data=c1F11()

global z;
global k;
global phi;

data=-Ccd2_22*Cd1_1 + Ccd1_21*Cd2_2;
