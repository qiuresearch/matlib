function data=c2F11()

global z;
global k;
global phi;

data=Ccd2_12*Cd1_1 - Ccd1_11*Cd2_2;