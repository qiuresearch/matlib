function y=aNumd0(d2)

global z;
global k;
global phi;

y=-Ccd2_22*d2*k(1)*v(1)+Ccd2_12*d2*k(1)*v(2);