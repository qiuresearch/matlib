function data=aFNumd11()

global z;
global k;
global phi;

data=a0*Ccd1_21*Ccd2_12-a0*Ccd1_11*Ccd2_22+Ccd2_22*Cd1_1*v(1)-Ccd1_21*Cd2_2*v(1)-Ccd2_12*Cd1_1*v(2)+Ccd1_11*Cd2_2*v(2);
