function data=c1F10()

global z;
global k;
global phi;

data=-Ccd1_21*k(2);