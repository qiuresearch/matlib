function data=c2F01()

global z;
global k;
global phi;

data=-Ccd2_12*k(1);