function data=abFDend11()

global z;
global k;
global phi;

data=Ccd1_21*Ccd2_12-Ccd1_11*Ccd2_22;