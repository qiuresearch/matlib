function data=Sk(kk, ehk)

global phi;

rou = phi*6/pi;
data =1 + rou * ehk;