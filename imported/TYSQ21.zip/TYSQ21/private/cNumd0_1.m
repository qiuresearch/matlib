function y=cNumd0_1(d2)

global z;
global k;
global phi;

y=-Ccd2_22(d2).*d2*k(1);