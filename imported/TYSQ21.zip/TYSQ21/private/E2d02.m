function data=E2d02()

global z;
global k;
global phi;

E=exp(1);
e=E;

data=12*c2F01*exp(z(2))*phi*sigma_d01(z(2))-12*c2F01*phi*tau_d01(z(2));