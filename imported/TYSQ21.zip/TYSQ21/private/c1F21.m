function data=c1F21()

global z;
global k;
global phi;

data=-Ccd2_22*Cdd1_11+Ccd1_21*Cdd2_12;