function data=c1F01()

global z;
global k;
global phi;

data=Ccd2_22*k(1);