function data=bFNumd10()

global z;
global k;
global phi;

data=Ccd1_21*k(2)*x(1) - Ccd1_11*k(2)*x(2);