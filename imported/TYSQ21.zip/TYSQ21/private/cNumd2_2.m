function y=c_Numd2_2(d2)

global z;
global k;
global phi;

y=-Ccd2_12*Cdd1_11*d2+Ccd1_11*Cdd2_12*d2;