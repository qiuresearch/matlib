function data=a0

global z;
global k;
global phi;

data=(1+2*phi)/(1-2*phi+phi^2);