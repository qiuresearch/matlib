function data=aFNumd10()

global z;
global k;
global phi;

data=Ccd1_21*k(2)*v(1)-Ccd1_11*k(2)*v(2);