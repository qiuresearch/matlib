function data=c2F12()

global z;
global k;
global phi;

data=Ccd2_12*Cdd1_12 - Ccd1_11 * Cdd2_22;