function y=cNumd2_1(d2)

global z;
global k;
global phi;

y=Ccd2_22*Cdd1_11*d2-Ccd1_21*Cdd2_12*d2;