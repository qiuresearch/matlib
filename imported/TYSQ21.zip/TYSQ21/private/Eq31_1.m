function y=Eq31_1(d1,d2,coe0,coe1,coe2,coe3)

y=coe0 + coe1 .* d1 + coe2 .* d1.^2 + coe3 .* d1.^3;