function y=bNumd0(d2)

global z;
global k;
global phi;

y=-Ccd2_22*d2*k(1)*x(1)+Ccd2_12*d2*k(1)*x(2);