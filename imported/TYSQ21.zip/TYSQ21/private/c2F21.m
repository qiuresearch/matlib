function data=c2F21()

global z;
global k;
global phi;

data=Ccd2_12*Cdd1_11 - Ccd1_11 * Cdd2_12;
