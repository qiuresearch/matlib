function data=c2F10()

global z;
global k;
global phi;

data=Ccd1_11*k(2);