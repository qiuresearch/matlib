function data=aFNumd21()

global z;
global k;
global phi;

data=Ccd2_22*Cdd1_11*v(1) - Ccd1_21*Cdd2_12*v(1) - Ccd2_12*Cdd1_11*v(2) + Ccd1_11*Cdd2_12*v(2)+Ccd1_21*Ccd2_12*w(1) - Ccd1_11 * Ccd2_22*w(1);