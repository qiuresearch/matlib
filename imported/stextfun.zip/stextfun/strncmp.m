function m = strncmp(a,b,n)
%STRNCMP String comparison.
%	STRNCMP(A,B,N) returns 1 if strings A and B each have at least
%	N characters and the first N characters of A and B match, otherwise
%	it returns 0.

%	Version 3.2b, 10 March 1997
%	Part of the Styled Text Toolbox
%	Copyright 1995-1997 by Douglas M. Schwarz.  All rights reserved.
%	schwarz@kodak.com

%	This function is only needed in MATLAB 4 as it is already available
%	in MATLAB 5 as a built-in function.

if length(a) >= n  &  length(b) >= n
	m = all( a(1:n) == b(1:n) );
else
	m = 0;
end
